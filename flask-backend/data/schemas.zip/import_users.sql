CREATE TABLE users (
    usrname VARCHAR(255) NOT NULL,
    psw VARCHAR(255) NULL,
    PRIMARY KEY (usrname)
);